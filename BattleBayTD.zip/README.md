# halo
this is my second project for game dev class. it's based on the mobile game `Battle Bay`, which i enjoy a lot

it's a work-in-progress for now
