simple main menu (expand later)

criticlal game elements
	base abstract enemy scene/class thing
		i.e.:
			health
			status effects (fire)
			take damage
			speed
			damage resistance
			basic shooting AI
			etc.
	base abstract enemy scene/class
		i.e:
			health
			status effects
			take damage
			speed
			damage resistance
			basic AI (???)
	currency:
		gold
		sugar
		pearls
		XP
	enemy waves system:
		probably read from a file ngl - that will be much easier
	base abstract weapons class:
		damage
		reload
		range (if applicable)
		critical chance (if applicable)
		bonus damage to burning enemies (if applicable)
		bonus damage to frozen enemies (if applicable)
		AOE radius (if applicable)
		effect duratin (if applicable)
		
